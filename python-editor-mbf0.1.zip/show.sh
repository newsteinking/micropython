#!/bin/bash
echo "http://localhost:8000/editor.html"
python3 -m http.server
