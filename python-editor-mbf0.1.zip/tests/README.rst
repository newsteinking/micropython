Python Code Editor Tests
========================

To run the tests point your browser at the tests.html file in the root of this
repository.

These tests target the Python specific code written for this editor. They use
the Jasmine (https://jasmine.github.io/) BDD test library.

Further tests *may* be written to exercise the wider TouchDevelop based code
used within the editor.
